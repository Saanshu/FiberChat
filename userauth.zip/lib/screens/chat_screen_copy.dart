
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '/chat/messages.dart';
import '/chat/new_message.dart';

class ChatScreenOK extends StatefulWidget {
  const ChatScreenOK({Key key}) : super(key: key);
  @override
  _ChatScreenOKState createState() => _ChatScreenOKState();
}

class _ChatScreenOKState extends State<ChatScreenOK> {
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:const Text('Group Chat'),
        actions: <Widget>[
          IconButton(onPressed: (){FirebaseAuth.instance.signOut();},
            icon: const Icon(Icons.exit_to_app))
        ],),
      body: Column(
        children: const <Widget>[
          Expanded(
            child: Messages(),
          ),
          NewMessage(),
        ],
      ),
    );
  }
}
