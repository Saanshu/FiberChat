import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/widgets/subtext.dart';

class Password extends StatefulWidget {
  const Password({Key key}) : super(key: key);

  @override
  _PasswordState createState() => _PasswordState();
}

class _PasswordState extends State<Password> {
  final _auth = FirebaseAuth.instance;
  final _formKey2 = GlobalKey<FormState>();
  String _userEmail;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
        appBar: AppBar(title: const Text('Reset Password'),),
        body: GestureDetector(
          onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
              height: 30,
            ),
            const Padding(
              padding: EdgeInsets.only(left: 10),
              child: Text('Enter email to reset your password', style: TextStyle(fontSize: 17.5),),
            ),
            Card(
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Form(
                  key: _formKey2,
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        TextFormField(
                          key: const ValueKey('email'),
                          keyboardType: TextInputType.emailAddress,
                          decoration: const InputDecoration(
                            labelText: 'Email address',
                          ),
                          onChanged: (value) {
                            setState(() {
                              _userEmail = value;
                            });
                          },
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        ElevatedButton(
                            onPressed: () async{
                              _auth.sendPasswordResetEmail(
                                  email: _userEmail);
                              Navigator.of(context)
                                  .pushReplacementNamed('/auth');
                            },
                            child: const Text(
                              'Send Email',
                              style: TextStyle(fontSize: 18),
                            ))
                      ]),
                ),
              ),
            ),
            const SizedBox(height: 320,),
            const SubText(),
              ],
            ),
          ),
        ));
  }
}
